from agent.main import predict

def main(task):
    return predict(task)
