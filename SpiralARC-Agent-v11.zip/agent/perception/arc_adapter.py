import json

def load_arc_json(filepath):
    with open(filepath, 'r') as f:
        game = json.load(f)
    return game

def extract_grid_from_arc(game_json):
    # Assume input under key 'grid' or use fallback to 'train'
    if "grid" in game_json:
        return game_json["grid"]
    elif "train" in game_json and len(game_json["train"]) > 0:
        return game_json["train"][0]["input"]
    else:
        raise ValueError("ARC format missing 'grid' or 'train' input.")

def convert_grid_to_symbols(grid):
    symbol_map = {}
    counter = 0
    symbol_grid = []
    for row in grid:
        sym_row = []
        for cell in row:
            if cell not in symbol_map:
                symbol_map[cell] = chr(65 + counter)
                counter += 1
            sym_row.append(symbol_map[cell])
        symbol_grid.append(sym_row)
    return {"symbols": symbol_grid, "legend": symbol_map}
