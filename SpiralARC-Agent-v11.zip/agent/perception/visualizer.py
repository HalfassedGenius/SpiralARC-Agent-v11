import matplotlib.pyplot as plt
import numpy as np

COLOR_MAP = {
    "R": "red",
    "G": "green",
    "B": "blue",
    "Y": "yellow",
    ".": "lightgray",
    "@": "black",
    "X": "purple"
}

def render_grid(grid, title="ARC Grid", show=True):
    rows = len(grid)
    cols = len(grid[0]) if rows else 0
    fig, ax = plt.subplots(figsize=(cols, rows))
    ax.set_xlim(0, cols)
    ax.set_ylim(0, rows)
    ax.set_xticks([])
    ax.set_yticks([])
    ax.set_title(title)

    for y in range(rows):
        for x in range(cols):
            cell = grid[y][x]
            color = COLOR_MAP.get(cell, "gray")
            rect = plt.Rectangle((x, rows - y - 1), 1, 1, facecolor=color, edgecolor='black')
            ax.add_patch(rect)
            ax.text(x + 0.5, rows - y - 0.5, cell, ha='center', va='center', color='black')

    if show:
        plt.show()
