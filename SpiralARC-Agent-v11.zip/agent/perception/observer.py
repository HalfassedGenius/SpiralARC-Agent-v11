# Observer module - extracts basic features from the raw environment grid

def observe_environment(raw_state):
    # Placeholder: pass through for now
    return raw_state
