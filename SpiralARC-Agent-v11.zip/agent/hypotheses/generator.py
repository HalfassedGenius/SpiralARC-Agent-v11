# Hypothesis generator with symbolic learning and merging

from collections import Counter, defaultdict

# Global symbolic rule memory
symbol_history = []
goal_memory = defaultdict(lambda: {"count": 0, "confidence": 0.5})

def generate_hypotheses(symbols):
    grid = symbols.get("symbols", [])
    flat = [cell for row in grid for cell in row if cell != '.']
    counts = Counter(flat)

    if not flat:
        return [{"goal": "grid_empty", "confidence": 1.0}]

    top_symbol = counts.most_common(1)[0][0]
    symbol_history.append(top_symbol)

    # Symbol merging: if same top symbol occurs in 3+ runs, reinforce it
    learned_goals = []
    if symbol_history.count(top_symbol) >= 3:
        goal_memory[f"remove_all_{top_symbol}"]["count"] += 1
        goal_memory[f"remove_all_{top_symbol}"]["confidence"] = min(1.0, goal_memory[f"remove_all_{top_symbol}"]["confidence"] + 0.05)

    # Merge high-confidence goals
    for goal, data in goal_memory.items():
        if data["confidence"] > 0.4:
            learned_goals.append({"goal": goal, "confidence": data["confidence"]})

    # Add current guesses to hypothesis pool
    hypotheses = [
        {"goal": f"remove_all_{top_symbol}", "confidence": 0.6},
        {"goal": f"reach_{grid[0][0]}_corner", "confidence": 0.4},
    ] + learned_goals

    return hypotheses
