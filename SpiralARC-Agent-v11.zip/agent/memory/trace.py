# Dashboard log for step-by-step trace

def print_trace(step, symbols, hypotheses, action, result):
    print(f"\n📘 Step {step}:")
    print("Grid Snapshot:")
    for row in symbols.get("symbols", []):
        print(" ".join(row))
    print("Hypotheses:")
    for h in hypotheses:
        print(f"  - {h['goal']} (conf: {h['confidence']:.2f})")
    print(f"Action Taken: {action}")
    print(f"Outcome: {result}")
