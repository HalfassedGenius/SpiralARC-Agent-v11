# Recorder module with symbolic feedback (Delta_n) logic

memory_log = []

def update_memory(env, symbols, hypotheses, action):
    result = env.last_outcome()  # mock method to get feedback from last action
    delta_info = []

    for hyp in hypotheses:
        # Check if outcome supports the hypothesis
        if hyp["goal"] in result.get("success_signals", []):
            hyp["confidence"] += 0.1
        else:
            hyp["confidence"] -= 0.1
        # Bound confidence between 0 and 1
        hyp["confidence"] = max(0.0, min(1.0, hyp["confidence"]))
        delta_info.append((hyp["goal"], hyp["confidence"]))

    memory_log.append({
        "symbols": symbols,
        "action": action,
        "result": result,
        "delta": delta_info
    })

    # For now, print feedback delta
    print("\n🔁 Feedback (∆ₙ) Update:")
    for goal, conf in delta_info:
        print(f"  Goal: {goal}, Adjusted Confidence: {conf:.2f}")
