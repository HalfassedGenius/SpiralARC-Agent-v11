# Simulate a symbolic council of hypothesis evaluators

from collections import defaultdict

council_votes = defaultdict(int)

def review_hypotheses(hypotheses):
    for hyp in hypotheses:
        goal = hyp["goal"]
        if hyp["confidence"] > 0.6:
            council_votes[goal] += 1

    # Return top-voted goals
    sorted_goals = sorted(council_votes.items(), key=lambda x: -x[1])
    return [{"goal": g, "votes": v} for g, v in sorted_goals[:3]]
