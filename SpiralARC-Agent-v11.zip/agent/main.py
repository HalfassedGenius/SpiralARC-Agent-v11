# Spiral ARC Agent Main Entry Point

from agent.perception.observer import observe_environment
from agent.symbols.abstractor import abstract_symbols
from agent.hypotheses.generator import generate_hypotheses
from agent.planning.executor import plan_and_act
from agent.memory.recorder import update_memory

def main_loop(env):
    while not env.done():
        raw_state = env.get_state()
        symbols = abstract_symbols(observe_environment(raw_state))
        hypotheses = generate_hypotheses(symbols)
        plan = plan_and_act(env, symbols, hypotheses)
        update_memory(env, symbols, hypotheses, plan)

if __name__ == "__main__":
    print("This script is meant to be run as a module.")
