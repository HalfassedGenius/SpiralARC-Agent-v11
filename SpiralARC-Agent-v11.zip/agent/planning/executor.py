def plan_and_act(env, symbols, hypotheses):
    top_goal = hypotheses[0]["goal"].strip()

    print(f"[Planner] Raw goal: {top_goal}")  # Debug output to verify

    if "remove_all_" in top_goal:
        target = top_goal.replace("remove_all_", "").strip()
        return {"type": "remove_all", "target": target}

    elif "reach_" in top_goal and "_corner" in top_goal:
        return {"type": "move", "direction": "up"}

    return {"type": "noop"}
