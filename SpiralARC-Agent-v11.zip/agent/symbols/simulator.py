def predict_next_state(symbols, action):
    grid = [row[:] for row in symbols["symbols"]]  # Deep copy

    if action.get("type") == "remove_all":
        target = action.get("target")
        for r in range(len(grid)):
            for c in range(len(grid[0])):
                if grid[r][c] == target:
                    grid[r][c] = "."

    elif action.get("type") == "move":
        # Simulate moving the first non-empty symbol to a corner
        for r in range(len(grid)):
            for c in range(len(grid[0])):
                if grid[r][c] not in [".", ""]:
                    value = grid[r][c]
                    grid[r][c] = "."
                    grid[0][0] = value
                    return {"symbols": grid}

    return {"symbols": grid}
